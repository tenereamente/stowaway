## v1.0.0:

* [COOK-1529] - add default logwatch.conf
* add test-kitchen support

## v0.1.1:

* Current released version.
