## v1.0.2:

### Bug

- [COOK-3164]: `partial_search` should use
  `Chef::Config[:chef_server_url]` instead of `search_url`

## v1.0.0:

- Initial release
