default['logwatch']['email'] = "root@localhost"
