name             'python_test'
maintainer       'Scott Likens'
maintainer_email 'scott@mopub.com'
license          'Apache 2.0'
description      'Installs/Configures python_test'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
