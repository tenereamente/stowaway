default["monitor"]["pagerduty_api_key"] = ""

default["monitor"]["graphite_address"] = nil
default["monitor"]["graphite_port"] = nil
