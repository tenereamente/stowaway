set_unless[:bundler][:apps_path] = "/home/ubuntu/apps"
