
default['rubygems']['gem_disable_default'] = false
default['rubygems']['gem_sources'] = [ 'https://rubygems.org' ]
default['rubygems']['chef_gem_disable_default'] = false
default['rubygems']['chef_gem_sources'] = [ 'https://rubygems.org' ]
