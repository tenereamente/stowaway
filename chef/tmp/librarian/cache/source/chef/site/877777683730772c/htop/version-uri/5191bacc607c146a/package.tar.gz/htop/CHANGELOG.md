# CHANGELOG for htop

This file is used to list changes made in each version of htop.

## 1.1.0:

* add RedHat/CentOS support

## 1.0.0:

* Initial release of htop
