## v2.0.4
* Fix usage of `fqdn`
* Fix log level usage
