name             "rubygems"
maintainer       "Apache v2"
maintainer_email "Sean OMeara <someara@opscode.com>"
license          "Apache2"
description      "Installs/Configures rubygems"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.3.0"

