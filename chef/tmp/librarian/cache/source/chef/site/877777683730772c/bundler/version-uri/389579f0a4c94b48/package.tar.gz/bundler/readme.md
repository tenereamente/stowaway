# Bundler Recipe

The default recipe installs bundler and this cookbook as the following also added recipes:

    # Executes bundle install at the app_path/app/current directory
    bundler:install

    # Executes bundle pack at the app_path/app/current directory
    bundler:pack

    # Executes bundle lock at the app_path/app/current directory
    bundler:lock
    
    # Executes bundle unlock at the app_path/app/current directory
    bundler:unlock


## Support

  Email Jack Russell Software 
  
  support@jackrussellsoftware.com 
  
  or
  
  http://support.jackrussellsoftware.com
  
  