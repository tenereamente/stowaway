## v0.6.2:

### Bug

- [COOK-2487]: when setting a node attribute you must specify the precedence
- [COOK-2982]: ufw cookbook has foodcritic failures
